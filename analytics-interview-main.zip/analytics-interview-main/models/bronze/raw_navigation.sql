select * from read_csv_auto(
    'data/raw_navigation.csv',
    header = true
)