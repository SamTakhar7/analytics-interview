select * from read_csv_auto(
    'data/raw_toolbar_transformations.csv',
    header = true
)